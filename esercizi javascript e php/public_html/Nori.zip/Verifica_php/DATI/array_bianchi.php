<?php
	$nomi = array(
		"Guidi"=> "Alberto", 
		"Albertini"=> "Alessandro", 		
		"Godi"=> "Emanuele", 				
		"Nori"=> "Rocco", 						
		"Pedote"=> "Antonio"); 								
		
	$residenze = array(
		"Albertini"=> "Roma", 		
		"Nori"=> "Pesaro", 						
		"Godi"=> "verona", 				
		"Pedote"=> "Napoli",
		"Guidi"=> "Napoli"); 										
		
												
?>
		
