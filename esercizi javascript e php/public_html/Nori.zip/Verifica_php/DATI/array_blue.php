<?php
	$nomi = array(
		"Berardi"=> "Martin", 
		"Giorgini"=> "Davide", 		
		"Zellini"=> "Marco", 				
		"Bostrenghi"=> "Matteo", 				
		"Pierotti"=> "Michele", 						
		"Fracassi"=> "Claudio"); 								
		
	$residenze = array(
		"Bostrenghi"=> "Roma", 				
		"Pierotti"=> "Matera", 						
		"Berardi"=> "Firenze", 
		"Zellini"=> "Ancona", 				
		"Giorgini"=> "Verona", 		
		"Fracassi"=> "Lecce");								

?>