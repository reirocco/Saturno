<?php
	require 'costanti.php';
	
	function creaClasse($classe){
	    
		
		return $;
    }
    
?>