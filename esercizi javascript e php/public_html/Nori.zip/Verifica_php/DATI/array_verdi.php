<?php
	$nomi = array(
		"Shehu"=> "Flavio", 
		"Evangelisti"=> "Luca", 		
		"Ziu"=> "Giorgio", 						
		"Fracassi"=> "Claudio");								

	$residenze = array(
		"Shehu"=> "Roma", 
		"Evangelisti"=> "Milano", 		
		"Ziu"=> "Milano", 						
		"Fracassi"=> "Trento"); 								
		
?>