<?php
    define("DAT_BIA","BIANCHI");
    define("DAT_VER","VERDI");
    define("DAT_BLU","BLUE");
?>