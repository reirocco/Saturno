<?php
	$users = array("pippo"=> "11111", "pluto"=> "22222", "paperino"=> "33333");		
	
?>
		
